import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  FlatList,
  ScrollView
} from "react-native";

import * as Contacts from "expo-contacts";
import * as Location from "expo-location";
import * as SMS from "expo-sms";

export default function App() {

  const [menuOpen, setMenuOpen] = useState(false);
  const [screen, setScreen] = useState("home");

  const [contacts, setContacts] = useState([]);
  const [name, setName] = useState("");
  const [number, setNumber] = useState("");

  // ✅ Enviar mensagem SOS
  async function sendEmergencyMessage() {

    if (contacts.length === 0) {
      alert("Adicione pelo menos um contato");
      return;
    }

    let { status } =
      await Location.requestForegroundPermissionsAsync();

    if (status !== "granted") {
      alert("Permissão de localização negada");
      return;
    }

    let location =
      await Location.getCurrentPositionAsync({});

    const latitude = location.coords.latitude;
    const longitude = location.coords.longitude;

    const message =
`🚨 EMERGÊNCIA 🚨

Preciso de ajuda!

Minha localização:
https://maps.google.com/?q=${latitude},${longitude}`;

    const phoneNumbers =
      contacts.map(contact => contact.number);

    const isAvailable =
      await SMS.isAvailableAsync();

    if (isAvailable) {

      await SMS.sendSMSAsync(
        phoneNumbers,
        message
      );

    } else {
      alert("SMS não disponível neste dispositivo");
    }
  }

  // ✅ Adicionar contato manualmente
  function addContact() {

    if (!name || !number) {
      alert("Preencha nome e número");
      return;
    }

    const newContact = {
      id: Date.now().toString(),
      name: name,
      number: number
    };

    setContacts(prevContacts => [...prevContacts, newContact]);

    setName("");
    setNumber("");
  }

  // ✅ Escolher contato da agenda
  async function pickContact() {

    const { status } =
      await Contacts.requestPermissionsAsync();

    if (status !== "granted") {
      alert("Permissão negada");
      return;
    }

    const { data } =
      await Contacts.getContactsAsync({
        fields: [Contacts.Fields.PhoneNumbers],
      });

    if (data.length > 0) {

      const contact = data.find(
        c => c.phoneNumbers &&
        c.phoneNumbers.length > 0
      );

      if (contact) {

        const newContact = {
          id: Date.now().toString(),
          name: contact.name,
          number: contact.phoneNumbers[0].number
        };

        setContacts(prev => [...prev, newContact]);

        alert("Contato adicionado com sucesso!");
      } else {
        alert("Nenhum contato com número encontrado");
      }
    }
  }

  // ✅ Remover contato
  function removeContact(id) {

    const updated =
      contacts.filter(item => item.id !== id);

    setContacts(updated);
  }

  // 📄 Tela contatos
  if (screen === "contatos") {

    return (
      <View style={styles.container}>

        <Text style={styles.logo}>
          Contatos de Emergência
        </Text>

        <TextInput
          placeholder="Nome"
          placeholderTextColor="#94a3b8"
          style={styles.input}
          value={name}
          onChangeText={setName}
        />

        <TextInput
          placeholder="Número"
          placeholderTextColor="#94a3b8"
          style={styles.input}
          keyboardType="numeric"
          value={number}
          onChangeText={setNumber}
        />

        <TouchableOpacity
          style={styles.addButton}
          onPress={addContact}
        >
          <Text style={styles.buttonText}>
            Adicionar contato
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.importButton}
          onPress={pickContact}
        >
          <Text style={styles.buttonText}>
            Escolher da agenda
          </Text>
        </TouchableOpacity>

        <FlatList
          data={contacts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (

            <View style={styles.contactRow}>

              <View>
                <Text style={styles.contactName}>
                  {item.name}
                </Text>

                <Text style={styles.contactNumber}>
                  {item.number}
                </Text>
              </View>

              <Text
                style={styles.removeContact}
                onPress={() => removeContact(item.id)}
              >
                Remover
              </Text>

            </View>

          )}
        />

        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setScreen("home")}
        >
          <Text style={styles.buttonText}>
            Voltar
          </Text>
        </TouchableOpacity>

      </View>
    );
  }

  // 📄 Tela Jurídica
  if (screen === "juridico") {

    return (

      <ScrollView style={styles.container}>

        <Text style={styles.logo}>
          Guia Jurídico
        </Text>

        <View style={styles.card}>

          <Text style={styles.cardTitle}>
            Lei Maria da Penha
          </Text>

          <Text style={styles.cardText}>
            A Lei Maria da Penha protege mulheres contra violência doméstica e familiar.
          </Text>

        </View>

        <View style={styles.card}>

          <Text style={styles.cardTitle}>
            Telefones de Emergência
          </Text>

          <Text style={styles.cardText}>
            Polícia Militar: 190
          </Text>

          <Text style={styles.cardText}>
            Central da Mulher: 180
          </Text>

          <Text style={styles.cardText}>
            SAMU: 192
          </Text>

        </View>

        <View style={styles.card}>

          <Text style={styles.cardTitle}>
            Como denunciar
          </Text>

          <Text style={styles.cardText}>
            Procure uma delegacia, ligue 180 ou registre boletim online.
          </Text>

        </View>

        <View style={styles.card}>

          <Text style={styles.cardTitle}>
            Medidas protetivas
          </Text>

          <Text style={styles.cardText}>
            A vítima pode solicitar medidas protetivas para afastamento do agressor.
          </Text>

        </View>

        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setScreen("home")}
        >
          <Text style={styles.buttonText}>
            Voltar
          </Text>
        </TouchableOpacity>

      </ScrollView>
    );
  }

  // 📄 Tela principal
  return (
    <View style={styles.container}>

      {/* BOTÃO MENU */}
      <TouchableOpacity
        style={styles.menuButton}
        onPress={() => setMenuOpen(!menuOpen)}
      >
        <Text style={styles.menuIcon}>☰</Text>
      </TouchableOpacity>

      {/* MENU LATERAL */}
      {menuOpen && (

        <View style={styles.overlay}>

          {/* Fundo escuro */}
          <TouchableOpacity
            style={{ flex: 1 }}
            activeOpacity={1}
            onPress={() => setMenuOpen(false)}
          />

          {/* Menu */}
          <View style={styles.menu}>

            <Text style={styles.menuTitle}>
              Menu
            </Text>

            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                setMenuOpen(false);
                setScreen("contatos");
              }}
            >
              <Text style={styles.menuText}>
                Contato de emergência
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => {
                setMenuOpen(false);
                setScreen("juridico");
              }}
            >
              <Text style={styles.menuText}>
                Guia Jurídico
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setMenuOpen(false)}
            >
              <Text style={styles.closeText}>
                Fechar
              </Text>
            </TouchableOpacity>

          </View>

        </View>
      )}

      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.logo}>
          SOS Mulher
        </Text>

        <Text style={styles.subtitle}>
          Segurança em primeiro lugar
        </Text>
      </View>

      {/* CENTRO */}
      <View style={styles.centerArea}>

        <TouchableOpacity
          style={styles.sosButton}
          onPress={sendEmergencyMessage}
        >
          <Text style={styles.sosText}>
            SOS
          </Text>
        </TouchableOpacity>

        <Text style={styles.instruction}>
          Pressione em caso de emergência
        </Text>

      </View>

      {/* FOOTER */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Sua localização será compartilhada com seus guardiões
        </Text>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#0f172a",
    padding: 40
  },

  // MENU BUTTON
  menuButton: {
    position: "absolute",
    top: 50,
    left: 20,
    zIndex: 2000,
    backgroundColor: "#1e293b",
    padding: 10,
    borderRadius: 12
  },

  menuIcon: {
    fontSize: 30,
    color: "white"
  },

  // OVERLAY
  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.6)",
    zIndex: 999
  },

  // MENU
  menu: {
    position: "absolute",
    top: 0,
    left: 0,
    width: 260,
    height: "100%",
    backgroundColor: "#1e293b",
    paddingTop: 100,
    paddingHorizontal: 25,
    borderTopRightRadius: 25,
    borderBottomRightRadius: 25
  },

  menuTitle: {
    color: "white",
    fontSize: 28,
    marginBottom: 30,
    fontWeight: "bold"
  },

  menuItem: {
    paddingVertical: 18
  },

  menuText: {
    color: "#cbd5f5",
    fontSize: 18
  },

  closeButton: {
    marginTop: 40
  },

  closeText: {
    color: "#ef4444",
    fontSize: 18,
    fontWeight: "bold"
  },

  // HEADER
  header: {
    alignItems: "center",
    marginTop: 40
  },

  logo: {
    fontSize: 30,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 1
  },

  subtitle: {
    color: "#94a3b8",
    marginTop: 8
  },

  // CENTER
  centerArea: {
    alignItems: "center",
    marginTop: 100
  },

  sosButton: {
    width: 200,
    height: 200,
    borderRadius: 110,
    backgroundColor: "#ef4444",
    justifyContent: "center",
    alignItems: "center"
  },

  sosText: {
    color: "#fff",
    fontSize: 50,
    fontWeight: "bold"
  },

  instruction: {
    color: "#cbd5f5",
    marginTop: 25,
    fontSize: 16
  },

  // FOOTER
  footer: {
    alignItems: "center",
    marginTop: 10
  },

  footerText: {
    color: "#64748b",
    textAlign: "center"
  },

  // INPUTS
  input: {
    backgroundColor: "#334155",
    color: "#fff",
    padding: 12,
    borderRadius: 8,
    marginTop: 20
  },

  addButton: {
    backgroundColor: "#ef4444",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 15
  },

  importButton: {
    backgroundColor: "#2563eb",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 10
  },

  buttonText: {
    color: "#fff",
    fontWeight: "bold"
  },

  // CONTACTS
  contactRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 15,
    backgroundColor: "#1e293b",
    padding: 12,
    borderRadius: 8
  },

  contactName: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold"
  },

  contactNumber: {
    color: "#94a3b8",
    marginTop: 4
  },

  removeContact: {
    color: "#ef4444",
    fontWeight: "bold"
  },

  // BACK BUTTON
  backButton: {
    marginTop: 40,
    marginBottom: 40,
    backgroundColor: "#ef4444",
    padding: 12,
    borderRadius: 8,
    alignItems: "center"
  },

  // CARDS
  card: {
    backgroundColor: "#1e293b",
    padding: 15,
    borderRadius: 10,
    marginTop: 15
  },

  cardTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8
  },

  cardText: {
    color: "#cbd5e1",
    fontSize: 14,
    lineHeight: 22
  }

});