from rest_framework import generics, permissions, status
from sosmulher.models import User, ContatoEmergencia, Incidente
from sosmulher.serializers import UserSerializer, ContatoEmergenciaSerializer, IncidenteSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

class UserRegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny]

class UserLoginSerializer(TokenObtainPairSerializer):
    username_field = 'email'

class UserLoginView(TokenObtainPairView):
    serializer_class = UserLoginSerializer

class UserProfileView(generics.RetrieveUpdateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def get_object(self):
        return self.request.user
    
class ContatoEmergenciaViewSet(viewsets.ModelViewSet):
    serializer_class = ContatoEmergenciaSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        return ContatoEmergencia.objects.all()
    
    def perform_create(self, serializer):
        from sosmulher.models import User
        # Pega o superusuário que você criou para não dar erro de Foreign Key
        usuario = User.objects.first() 
        serializer.save(user=usuario)

class IniciarAlertaView(generics.CreateAPIView):
    queryset = Incidente.objects.all()
    serializer_class = IncidenteSerializer
    permission_classes = [permissions.AllowAny]

    def perform_create(self, serializer):
        from sosmulher.models import User
        usuario = User.objects.first()
        # Salva o alerta de GPS vinculado ao seu usuário
        serializer.save(user=usuario, status='pendente')
    
class VerificarAlertaView(APIView):
    permission_classes = [permissions.AllowAny]

    def patch(self, request, pk):
        try:
            incidente = Incidente.objects.get(pk=pk, user=request.user, status='pendente')
        except Incidente.DoesNotExist:
            return Response(
                {"error": "Alerta não encontrado, já resolvido ou permissão negada."}, 
                status=status.HTTP_404_NOT_FOUND
            )
        novo_status = request.data.get('status')
        if novo_status not in ['disparado', 'cancelado']:
            return Response(
                {"error": "Status inválido. Escolha 'disparado' ou 'cancelado'."}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        incidente.status = novo_status
        incidente.save()
        return Response({
            "mensagem": f"O incidente foi registrado como: {incidente.get_status_display()}"
        }, status=status.HTTP_200_OK)

class HistoricoIncidentesListView(generics.ListAPIView):
    serializer_class = IncidenteSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        return Incidente.objects.filter(user=self.request.user).order_by('-data_criacao')
