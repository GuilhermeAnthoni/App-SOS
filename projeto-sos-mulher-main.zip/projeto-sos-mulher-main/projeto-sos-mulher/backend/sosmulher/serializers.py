from rest_framework import serializers
from sosmulher.models import User, ContatoEmergencia, Incidente

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'email', 'telefone', 'cpf', 'password']
        extra_kwargs = {
            'password': {'write_only': True}
        }
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

class ContatoEmergenciaSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContatoEmergencia
        fields = ['id', 'nome', 'telefone']

class IncidenteSerializer(serializers.ModelSerializer):
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    class Meta:
        model = Incidente
        fields = ['id', 'data_criacao', 'latitude', 'longitude', 'status', 'status_display']
        read_only_fields = ['id', 'data_criacao', 'status']