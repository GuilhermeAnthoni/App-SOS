from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from sosmulher.models import User 

class CustomerUserAdmin(UserAdmin):
    list_display = ('first_name', 'last_name', 'email', 'telefone')
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Informações Pessoais', {'fields': ('first_name', 'last_name', 'telefone', 'cpf')}),
        ('Permissões', {'fields': ('is_active', 'is_staff', 'is_superuser')}),
    )

admin.site.register(User, CustomerUserAdmin)
