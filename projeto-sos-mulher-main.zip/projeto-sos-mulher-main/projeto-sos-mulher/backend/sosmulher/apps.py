from django.apps import AppConfig


class SosmulherConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sosmulher'
