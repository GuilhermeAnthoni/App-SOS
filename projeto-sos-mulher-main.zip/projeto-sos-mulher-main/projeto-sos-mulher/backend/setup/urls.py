from django.contrib import admin
from django.urls import path, include
from sosmulher.views import UserRegisterView, UserProfileView, UserLoginView, ContatoEmergenciaViewSet, IniciarAlertaView, VerificarAlertaView, HistoricoIncidentesListView
from rest_framework_simplejwt.views import TokenRefreshView
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('contatos', ContatoEmergenciaViewSet, basename='Contato')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api-auth/', include('rest_framework.urls')),
    path('api/cadastro/', UserRegisterView.as_view(), name='user-register'),
    path('api/login/', UserLoginView.as_view(), name='user-login'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token-refresh'),
    path('api/perfil/', UserProfileView.as_view(), name='user-profile'),
    path('api/', include(router.urls)),
    path('api/alerta/iniciar/', IniciarAlertaView.as_view(), name='iniciar-alerta'),
    path('api/alerta/resolver/<int:pk>/', VerificarAlertaView.as_view(), name='verificar-alerta'),
    path('api/alerta/historico/', HistoricoIncidentesListView.as_view(), name='historico-alerta'),
]
