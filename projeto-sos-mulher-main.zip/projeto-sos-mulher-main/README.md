# Projeto SOS Mulher 🚨

Este é um sistema de proteção e alerta de emergência composto por um aplicativo móvel (React Native/Expo) e uma API (Python/Django Rest Framework).
